import 'dart:math';
import 'dart:convert';
import 'package:allo_thieb/help/app_colors.dart';
import 'package:allo_thieb/help/constants.dart';
import 'package:allo_thieb/help/custom_text.dart';
import 'package:allo_thieb/help/loading.dart';
import 'package:flutter/material.dart';
import 'package:responsive_table/responsive_table.dart';
import 'package:http/http.dart' as http;
import 'package:dio/dio.dart';

class DataPage extends StatefulWidget {
  @override
  _DataPageState createState() => _DataPageState();
}

class _DataPageState extends State<DataPage> {
  List<DatatableHeader> _headers = [
    DatatableHeader(
        text: "ID",
        value: "id",
        show: true,
        sortable: true,
        textAlign: TextAlign.left),
    DatatableHeader(
        text: "Nom",
        value: "nom",
        show: true,
        sortable: true,
        textAlign: TextAlign.left),
    DatatableHeader(
        text: "Type Livraison",
        value: "livraison",
        show: true,
        sortable: true,
        textAlign: TextAlign.left),
    DatatableHeader(
        text: "Heure",
        value: "heure",
        show: true,
        sortable: true,
        textAlign: TextAlign.left),
  ];

  List<int> _perPages = [5, 10, 15, 100];
  int _total = 100;
  var _currentPerPage;
  int _currentPage = 1;
  bool _isSearch = false;
  List<Map<String, dynamic>> _source = <Map<String, dynamic>>[];
  List<Map<String, dynamic>> _selecteds = <Map<String, dynamic>>[];
  String _selectableKey = "id";

  String _sortColumn = "";
  bool _sortAscending = true;
  bool _isLoading = true;
  bool _showSelect = true;
  List list = [];
  bool vf = true;

  List<Map<String, dynamic>> _generateData(commande_recente) {
    List<Map<String, dynamic>> temps = <Map<String, dynamic>>[];
    var i = 1;
    for (var data in commande_recente) {
      temps.add({
        "id": i,
        "nom": data['userInfo']['nom'],
        "livraison": data['typeLivraison'],
        "heure": "00 min-$i",
      });
      i++;
    }
    return temps;
  }

  Future getData() async {
    Response res;
    var dio = Dio();
    res = await dio.get(apiCommandeRecente);
    print(res.data.toString());
// Optionally the request above could also be done as
//     res = await dio.get('/test', queryParameters: {'id': 12, 'name': 'wendu'});
//     print(res.data.toString());

    setState(() => _isLoading = true);
    final http.Response response = await http.get(Uri.parse(apiCommandeRecente),
        headers: {"Content-Type": "application/json"}).timeout(
      Duration(seconds: 5),
      onTimeout: () {
        setState(() {
          vf = false;
          _isLoading = false;
          _source.addAll(_generateData(list));
        });
        // Time has run out, do what you wanted to do.
        return http.Response('Error', 500); // Replace 500 with your http code.
      },
    );
    if (response.statusCode == 200) {
      list = jsonDecode(response.body);
      _source.addAll(_generateData(list));
      setState(() {
        vf = false;
        _isLoading = false;
      });
      return response.statusCode;
    } else {
      setState(() {
        vf = false;
        _isLoading = false;
      });
      list = ["R.A.S"];
      return response.statusCode;
    }
  }

  @override
  void initState() {
    super.initState();
    getData();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
        child: Container(
      padding: EdgeInsets.all(defaultPadding),
      decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(8),
          boxShadow: const [
            BoxShadow(color: Colors.grey, offset: Offset(0, 3), blurRadius: 4)
          ]),
      child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          mainAxisSize: MainAxisSize.max,
          children: [
            Container(
              child: CustomText(
                color: blueFont,
                text: "Commandes récentes",
                size: 20,
                weight: FontWeight.bold,
              ),
            ),
            Container(
              margin: EdgeInsets.all(10),
              padding: EdgeInsets.all(0),
              constraints: BoxConstraints(
                maxHeight: 700,
              ),
              child: Card(
                elevation: 1,
                shadowColor: Colors.black,
                clipBehavior: Clip.none,
                child: vf
                    ? Loading()
                    : ResponsiveDatatable(
                        title: !_isSearch
                            ? RaisedButton.icon(
                                onPressed: () {
                                  print("ajoute");
                                },
                                icon: Icon(Icons.add),
                                label: Text("ADD"))
                            : null,
                        actions: [
                          if (_isSearch)
                            Expanded(
                                child: TextField(
                              decoration: InputDecoration(
                                  prefixIcon: IconButton(
                                      icon: Icon(Icons.cancel),
                                      onPressed: () {
                                        setState(() {
                                          _isSearch = false;
                                        });
                                      }),
                                  suffixIcon: IconButton(
                                      icon: Icon(Icons.search),
                                      onPressed: () {})),
                            )),
                          if (!_isSearch)
                            IconButton(
                                icon: Icon(Icons.search),
                                onPressed: () {
                                  setState(() {
                                    _isSearch = true;
                                  });
                                })
                        ],
                        headers: _headers,
                        source: _source,
                        selecteds: _selecteds,
                        showSelect: _showSelect,
                        autoHeight: false,
                        onTabRow: (data) {
                          print(data);
                        },
                        onSort: (value) {
                          setState(() {
                            _sortColumn = value;
                            _sortAscending = !_sortAscending;
                            if (_sortAscending) {
                              _source.sort((a, b) => b["$_sortColumn"]
                                  .compareTo(a["$_sortColumn"]));
                            } else {
                              _source.sort((a, b) => a["$_sortColumn"]
                                  .compareTo(b["$_sortColumn"]));
                            }
                          });
                        },
                        sortAscending: _sortAscending,
                        sortColumn: _sortColumn,
                        isLoading: _isLoading,
                        onSelect: (value, item) {
                          print("$value  $item ");
                          if (value) {
                            setState(() => _selecteds.add(item));
                          } else {
                            setState(() =>
                                _selecteds.removeAt(_selecteds.indexOf(item)));
                          }
                        },
                        onSelectAll: (value) {
                          if (value) {
                            setState(() => _selecteds =
                                _source.map((entry) => entry).toList().cast());
                          } else {
                            setState(() => _selecteds.clear());
                          }
                        },
                        footers: [
                          Container(
                            padding: EdgeInsets.symmetric(horizontal: 15),
                            child: Text(
                              "Elements par page:",
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          if (_perPages != null)
                            Container(
                              padding: EdgeInsets.symmetric(horizontal: 15),
                              child: DropdownButton(
                                  value: _currentPerPage,
                                  items: _perPages
                                      .map((e) => DropdownMenuItem(
                                            child: Text("$e"),
                                            value: e,
                                          ))
                                      .toList(),
                                  onChanged: (value) {
                                    setState(() {
                                      _currentPerPage = (value) as int;
                                    });
                                  }),
                            ),
                          Container(
                            padding: EdgeInsets.symmetric(horizontal: 15),
                            child: Text(
                                "$_currentPage - $_currentPerPage sur $_total"),
                          ),
                          IconButton(
                            icon: Icon(
                              Icons.arrow_back_ios,
                              size: 16,
                            ),
                            onPressed: () {
                              setState(() {
                                _currentPage =
                                    _currentPage >= 2 ? _currentPage - 1 : 1;
                              });
                            },
                            padding: EdgeInsets.symmetric(horizontal: 15),
                          ),
                          IconButton(
                            icon: Icon(Icons.arrow_forward_ios, size: 16),
                            onPressed: () {
                              setState(() {
                                _currentPage++;
                              });
                            },
                            padding: EdgeInsets.symmetric(horizontal: 15),
                          )
                        ],
                      ),
              ),
            ),
          ]),
    ));
    // floatingActionButton: FloatingActionButton(
    //   onPressed: () {
    //     _initData();
    //   },
    //   child: Icon(Icons.add),
    // ),
  }
}
