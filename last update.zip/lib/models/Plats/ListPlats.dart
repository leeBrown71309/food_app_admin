import 'dart:convert';
import 'package:allo_thieb/help/apiGetPost.dart';
import 'package:allo_thieb/help/app_colors.dart';
import 'package:allo_thieb/help/constants.dart';
import 'package:allo_thieb/help/custom_text.dart';
import 'package:allo_thieb/help/loading.dart';
import 'package:allo_thieb/help/onHoverbutton.dart';
import 'package:allo_thieb/screens/main/main_screen.dart';
import 'package:allo_thieb/screens/main/side_menu_pages/edit_plat_jour.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:ndialog/ndialog.dart';
import 'package:sizer/sizer.dart';
import '../../main.dart';
import '../../responsive.dart';
import 'ListPlatsInfos.dart';
import 'package:focused_menu/focused_menu.dart';
import 'package:focused_menu/modals.dart';

TextEditingController prix = TextEditingController();
TextEditingController description = TextEditingController();
TextEditingController image = TextEditingController();
TextEditingController nom = TextEditingController();

class ListPlats extends StatefulWidget {
  const ListPlats({Key? key}) : super(key: key);

  @override
  _ListPlatsState createState() => _ListPlatsState();
}

class _ListPlatsState extends State<ListPlats> {
  @override
  Widget build(BuildContext context) {
    final Size _size = MediaQuery.of(context).size;
    return Padding(
      padding: const EdgeInsets.all(defaultPadding),
      child: Column(
        children: [
          SizedBox(height: defaultPadding),
          Responsive(
            Mobile: ListPlatCardGridView(
              crossAxisCount: _size.width < 850 ? 2 : 4,
              childAspectRatio:
                  _size.width < 850 && _size.width > 350 ? 0.8 : 1,
            ),
            Tablet: ListPlatCardGridView(
              crossAxisCount: _size.width < 1100 ? 3 : 4,
              childAspectRatio:
                  _size.width < 1100 && _size.width > 850 ? 0.9 : 0.9,
            ),
            Desktop: ListPlatCardGridView(
              childAspectRatio:
                  _size.width < 1400 && _size.width > 1100 ? 1 : 1,
            ),
          ),
        ],
      ),
    );
  }
}

class ListPlatCardGridView extends StatefulWidget {
  const ListPlatCardGridView({
    Key? key,
    this.crossAxisCount = 4,
    this.childAspectRatio = 1,
  }) : super(key: key);

  final int crossAxisCount;
  final double childAspectRatio;

  @override
  State<ListPlatCardGridView> createState() => _ListPlatCardGridView();
}

class _ListPlatCardGridView extends State<ListPlatCardGridView> {
  var list = [];
  bool vf = true;
  var cardImage = 'https://source.unsplash.com/random/800x600?Food';

  Future getData() async {
    final http.Response response = await http.get(Uri.parse(apiPlat_get));
    if (response.statusCode == 200) {
      setState(() {
        vf = false;
      });
      list = jsonDecode(response.body);
    } else {
      list = ["R.A.S"];
    }
  }

  popUpError() {
    return NAlertDialog(
      title: Text("Attention!"),
      content: Text("Echec de connexion"),
      blur: 2,
    ).show(context, transitionType: DialogTransitionType.Bubble);
  }

/*
  Widget ListPlatbuildGridView() {
    return vf
        ? Center(child: Loading())
        : list[0] == "R.A.S"
            ? popUpError()
            : GridView.builder(
                physics: NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                itemCount: list.length,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: widget.crossAxisCount,
                  crossAxisSpacing: defaultPadding,
                  mainAxisSpacing: defaultPadding,
                  childAspectRatio: widget.childAspectRatio,
                ),
                itemBuilder: (context, index) => FocusedMenuHolder(
                    menuWidth: MediaQuery.of(context).size.width * 0.50,
                    blurSize: 5.0,
                    menuItemExtent: 45,
                    menuBoxDecoration: BoxDecoration(
                        color: Colors.grey,
                        borderRadius: BorderRadius.all(Radius.circular(15.0))),
                    duration: Duration(milliseconds: 100),
                    animateMenuItems: true,
                    blurBackgroundColor: Colors.black54,
                    bottomOffsetHeight: 100,
                    openWithTap: true,
                    menuItems: <FocusedMenuItem>[
                      FocusedMenuItem(
                          title: Text(
                            "Open",
                            style: TextStyle(color: black),
                          ),
                          trailingIcon: Icon(
                            Icons.open_in_new,
                            color: black,
                          ),
                          onPressed: () {
                            // Navigator.push(context, MaterialPageRoute(builder: (context)=>ScreenTwo()));
                          }),
                      FocusedMenuItem(
                          title: Text(
                            "Share",
                            style: TextStyle(color: black),
                          ),
                          trailingIcon: Icon(Icons.share, color: black),
                          onPressed: () {}),
                      FocusedMenuItem(
                          title: Text(
                            "Favorite",
                            style: TextStyle(color: black),
                          ),
                          trailingIcon:
                              Icon(Icons.favorite_border, color: black),
                          onPressed: () {}),
                      FocusedMenuItem(
                          title: Text(
                            "Delete",
                            style: TextStyle(color: Colors.redAccent),
                          ),
                          trailingIcon: Icon(
                            Icons.delete,
                            color: Colors.redAccent,
                          ),
                          onPressed: () {}),
                    ],
                    onPressed: () {},
                    child: Card(
                      child: PlatCard(
                        info: list[index],
                        isEditing: false,
                      ),
                    )
                ),
              );
  }
*/
  @override
  void initState() {
    super.initState();
    getData();
  }

  @override
  Widget build(BuildContext context) {
    void _showDialog(Map info) {
      Roww np = Roww("Nom du plat :", info['nomPlat'], nom);
      Roww ip = Roww("image :", info['image'], image);
      Roww pp = Roww("Prix :", info['prix'], prix);
      Map couleur_choisis = {"red": false, "blue": false, "black": false};
      var couleur = "white";
      final blue = Color(0xff0658b3);
      final red = Color(0xffbf0916);
      final noir = Color(0xff070707);
      bool couleurJetonBleu = false;
      bool couleurJetonRouge = false;
      bool couleurJetonNoir = false;

      switch (info['jeton']) {
        case "red":
          {
            couleur = "red";
            couleurJetonRouge = true;
          }
          break;
        case "blue":
          {
            couleur = "blue";
            couleurJetonBleu = true;
          }
          break;
        case "black":
          {
            couleur = "black";
            couleurJetonNoir = true;
          }
          break;
      }

      _insert() {
        var values = {
          'nomPlat': nom.text,
          'descriptionPlat': description.text,
          'jeton': couleur,
          'prix': prix.text,
          'image': image.text,
          'id': info['id'],
        };
        var req = CallApiPost();
        req.postData(values, apiPlat_mod);
      }

      void checked(titre, value) {
        switch (titre) {
          case "Blue":
            {
              couleurJetonBleu = value!;
              couleurJetonBleu ? couleur = "blue" : couleur = "white";
              couleur_choisis['blue'] = value;
              couleurJetonRouge = false;
              couleurJetonNoir = false;
            }
            break;

          case "Rouge":
            {
              couleurJetonRouge = value!;
              couleurJetonRouge ? couleur = "red" : couleur = "white";
              couleur_choisis['red'] = value;
              couleurJetonBleu = false;
              couleurJetonNoir = false;
            }
            break;

          case "Noir":
            {
              couleurJetonNoir = value!;
              couleurJetonNoir ? couleur = "black" : couleur = "white";
              couleur_choisis['black'] = value;
              couleurJetonBleu = false;
              couleurJetonRouge = false;
            }
            break;

          default:
            {
              couleurJetonNoir = value!;
              couleurJetonNoir ? couleur = "black" : couleur = "white";
              couleur_choisis['black'] = value;
              couleurJetonBleu = false;
              couleurJetonRouge = false;
            }
            break;
        }
      }

      Widget _buildCheckbox(color, titre, checkColor, cjt) {
        return Container(
          height: 30.0,
          child: Row(
            children: <Widget>[
              Theme(
                data: ThemeData(unselectedWidgetColor: Colors.black54),
                child: Checkbox(
                  value: cjt,
                  checkColor: checkColor,
                  activeColor: Colors.white,
                  onChanged: (value) {
                    setState(() {
                      checked(titre, value);
                    });
                  },
                ),
              ),
              Text(
                titre,
                style: TextStyle(color: Colors.black54),
              ),
              Icon(
                Icons.stop_circle_outlined,
                color: color,
                size: 30,
              )
            ],
          ),
        );
      }

      // flutter defined function
      showDialog(
        context: context,
        builder: (BuildContext context) {
          // return object of type Dialog
          return AlertDialog(
            backgroundColor: Colors.white,
            title: Row(
              children: [
                Expanded(
                  flex: 3,
                  child: Text(
                    "Modifier " + info['nomPlat'],
                    style: TextStyle(
                        color: Colors.black54,
                        fontWeight: FontWeight.w700,
                        fontSize: 6.sp),
                  ),
                ),
              ],
            ),
            content: Container(
                height: 400,
                width: 500,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    np.row(),
                    Divider(
                      height: 3,
                      color: Colors.black,
                    ),
                    pp.row(),
                    Divider(
                      height: 3,
                      color: Colors.black,
                    ),
                    Text("Description : "),
                    Expanded(
                      child: Container(
                        height: 100,
                        decoration: BoxDecoration(
                            border: Border.all(
                              color: Colors.green,
                              width: 2,
                            ),
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(10)),
                        child: TextField(
                          controller: description,
                          decoration: InputDecoration(
                              hoverColor: Colors.white54,
                              suffixIcon: Icon(
                                Icons.edit,
                                color: white,
                              ),
                              border: InputBorder.none,
                              hintText: info['description'],
                              hintStyle: TextStyle(color: Colors.redAccent),
                              icon: Icon(
                                Icons.edit,
                                color: white,
                              )),
                        ),
                      ),
                    ),
                    Divider(
                      height: 3,
                      color: Colors.black,
                    ),
                    ip.row(),
                    Divider(
                      height: 3,
                      color: Colors.black,
                    ),
                    Row(
                      children: [
                        Expanded(
                          flex: 2,
                          child: Text("Jeton : "),
                        ),
                        Expanded(
                            flex: 4,
                            child: Column(
                              children: [
                                _buildCheckbox(blue, "Blue", Colors.blueAccent,
                                    couleurJetonBleu),
                                _buildCheckbox(red, "Rouge", Colors.red,
                                    couleurJetonRouge),
                                _buildCheckbox(noir, "Noir", Colors.black,
                                    couleurJetonNoir),
                              ],
                            )),
                      ],
                    ),
                  ],
                )),
            actions: <Widget>[
              // usually buttons at the bottom of the dialog
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  FlatButton(
                      color: Color(0xb7073662),
                      onPressed: () {
                        nom.text == ""
                            ? nom.text = info['nomPlat']
                            : nom.text = nom.text;
                        prix.text == ""
                            ? prix.text = info['prix']
                            : prix.text = prix.text;
                        description.text == ""
                            ? description.text = info['descriptionPlat']
                            : description.text = description.text;
                        image.text == ""
                            ? image.text = info['image']
                            : image.text = image.text;
                        _insert();
                        Navigator.of(context).pop();
                        var screen_refresh = MainScreen();
                        screen_refresh.screen = EditPlatJour();
                        Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(
                                builder: (BuildContext context) =>
                                    buildMaterialApp(context, screen_refresh)));

                        nom.text = "";
                        description.text = "";
                        prix.text = "";
                        image.text = "";
                      },
                      child: new Text("Ok")),
                  SizedBox(
                    width: 1.w,
                  ),
                  RaisedButton(
                    elevation: 2,
                    color: Colors.white,
                    child: new Text("Close",
                        style: TextStyle(
                          color: Color(0xb7073662),
                        )),
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                  ),
                ],
              )
            ],
          );
        },
      );
    }

    _del(id) {
      var values = {
        'id': id,
      };
      var req = CallApiPost();
      req.postData(values, apiPlat_del);
    }

    Widget ListPlatbuildGridView() {
      return vf
          ? Center(child: Loading())
          : list[0] == "R.A.S"
              ? popUpError()
              : SafeArea(
                  child: GridView.builder(
                    physics: NeverScrollableScrollPhysics(),
                    shrinkWrap: true,
                    itemCount: list.length,
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: widget.crossAxisCount,
                      crossAxisSpacing: defaultPadding,
                      mainAxisSpacing: defaultPadding,
                      childAspectRatio: widget.childAspectRatio,
                    ),
                    itemBuilder: (context, index) => FocusedMenuHolder(
                        menuItems: [
                          FocusedMenuItem(
                            title: Text('Ouvrir'),
                            trailingIcon: Icon(Icons.open_in_new),
                            onPressed: () {},
                          ),
                          FocusedMenuItem(
                            title: Text('Modifier'),
                            trailingIcon: Icon(Icons.edit),
                            onPressed: () {
                              _showDialog(list[index]);
                              print(list[index]);
                            },
                          ),
                          FocusedMenuItem(
                            title: Text('Supprimer',
                                style: TextStyle(color: Colors.white)),
                            trailingIcon:
                                Icon(Icons.delete_forever, color: Colors.white),
                            backgroundColor: Colors.red,
                            onPressed: () {
                              _del(list[index]['id']);
                              print(list[index]['id']);
                              var screen_refresh = MainScreen();
                              screen_refresh.screen = EditPlatJour();
                              Navigator.pushReplacement(
                                  context,
                                  MaterialPageRoute(
                                      builder: (BuildContext context) =>
                                          buildMaterialApp(
                                              context, screen_refresh)));
                            },
                          ),
                        ],
                        blurSize: 8,
                        blurBackgroundColor: Colors.black54,
                        menuWidth: MediaQuery.of(context).size.width * 0.5,
                        menuItemExtent: 50,
                        duration: Duration(seconds: 0),
                        animateMenuItems: true,
                        menuOffset: 12,
                        openWithTap: true,
                        onPressed: () {},
                        child: Container(
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20)),
                          child: OnHoverCard(
                            child: Card(
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10)),
                                clipBehavior: Clip.antiAlias,
                                elevation: 3.0,
                                shadowColor: Color(0x8811b1e7),
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Container(
                                      height: 20.h,
                                      child: Stack(
                                        children: [
                                          Ink.image(
                                            //image plat
                                            image: NetworkImage(cardImage),
                                            fit: BoxFit.cover,
                                          ),
                                        ],
                                      ),
                                    ),
                                    Container(
                                      padding: EdgeInsets.only(
                                        top: 10,
                                        left: 16,
                                        right: 16,
                                      ),
                                      alignment: Alignment.center,
                                      child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Text(
                                            list[index]["nomPlat"],
                                            style: TextStyle(
                                                fontSize: 20,
                                                fontWeight: FontWeight.bold),
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ],
                                      ),
                                    ),
                                    Align(
                                        alignment: Alignment.center,
                                        child: Padding(
                                          padding: const EdgeInsets.all(16),
                                          child: Column(
                                            children: [
                                              Text(
                                                "Prix : ${list[index]["prix"]} FCFA",
                                              ),

                                              //essaie de faire en sorte qu'on puisse afficher aussi la quantité
                                            ],
                                          ),
                                        )),
                                  ],
                                )),
                          ),
                        )
                        /*
           PlatCard(
             info: list[index],
             isEditing: false,
           ),

            */
                        ),
                  ),
                );
    }

    return ListPlatbuildGridView();
  }
}

Padding textField(String ht, IconData icon1, IconData icon2,
    TextEditingController? controller) {
  return Padding(
    padding: const EdgeInsets.symmetric(horizontal: 20),
    child: Container(
      decoration: BoxDecoration(
          border: Border.all(
            color: Colors.green,
            width: 2,
          ),
          color: Colors.white,
          borderRadius: BorderRadius.circular(10)),
      child: Padding(
        padding: const EdgeInsets.only(left: 8.0),
        child: TextField(
          controller: controller,
          decoration: InputDecoration(
              hoverColor: Colors.white54,
              suffixIcon: Icon(
                icon1,
                color: white,
              ),
              border: InputBorder.none,
              hintText: ht,
              hintStyle: TextStyle(color: Colors.redAccent),
              icon: Icon(
                icon2,
                color: white,
              )),
        ),
      ),
    ),
  );
}

class Roww {
  String param1, param2;
  var entry;
  Roww(this.param1, this.param2, TextEditingController controller) {
    this.entry = Expanded(
        flex: 4,
        child: textField(this.param2, Icons.edit, Icons.edit, controller));
  }
  Row row() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [Expanded(flex: 2, child: Text(this.param1)), entry],
    );
  }
}
